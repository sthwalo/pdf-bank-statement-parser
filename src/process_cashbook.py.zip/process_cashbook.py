import pandas as pd
import os
import re
import openpyxl
from openpyxl.utils import get_column_letter

from datetime import datetime

def combine_csv_files(input_dir, start_date, end_date):
    """
    Combine multiple CSV files within the specified date range.
    """
    print(f"Reading CSV files from {input_dir} for period {start_date} to {end_date}")
    
    # Convert dates to datetime objects
    start_dt = pd.to_datetime(start_date)
    end_dt = pd.to_datetime(end_date)
    
    # List to store individual dataframes
    dfs = []
    
    # Read each CSV file
    for filename in os.listdir(input_dir):
        if filename.endswith('.csv'):
            file_path = os.path.join(input_dir, filename)
            print(f"Processing {filename}")
            
            try:
                # Read CSV with semicolon separator and skip the header row
                df = pd.read_csv(file_path, sep=';', skiprows=1,
                               names=['date', 'description', 'amount', 'balance', 'bank_fee'])
                
                # Convert date column to datetime using the YYYY-MM-DD format
                df['date'] = pd.to_datetime(df['date'], format='%Y-%m-%d')
                
                # Filter data within the date range
                mask = (df['date'] >= start_dt) & (df['date'] <= end_dt)
                df = df[mask]
                
                if not df.empty:
                    dfs.append(df)
                    print(f"Added {len(df)} rows from {filename}")
                    
            except Exception as e:
                print(f"Error processing {filename}: {str(e)}")
                continue
    
    # Combine all dataframes
    if dfs:
        combined_df = pd.concat(dfs, ignore_index=True)
        combined_df = combined_df.sort_values('date')
        print(f"Combined {len(dfs)} CSV files, total rows: {len(combined_df)}")
        return combined_df
    else:
        raise ValueError("No data found for the specified date range")

def clean_and_process_csv(df):
    """
    Clean and process the DataFrame to create a proper cashbook.
    """
    print("Processing combined data")
    
    # Clean up the DataFrame
    # Remove rows where amount is empty
    df = df.dropna(subset=['amount'])
    
    # Convert amount to numeric
    df['amount'] = pd.to_numeric(df['amount'], errors='coerce')
    
    # Determine transaction type
    df['Type'] = df['amount'].apply(lambda x: 'Credit' if x > 0 else 'Debit')
    
    # Create separate Debit and Credit columns
    df['Debit'] = df['amount'].apply(lambda x: abs(x) if x < 0 else 0)
    df['Credit'] = df['amount'].apply(lambda x: x if x > 0 else 0)
    
    # Clean up the Balance column
    df['balance'] = pd.to_numeric(df['balance'], errors='coerce')
    
    # Clean up the bank_fee column
    df['bank_fee'] = pd.to_numeric(df['bank_fee'], errors='coerce')
    
    # Categorize transactions
    df = categorize_transactions(df)
    
    return df

def categorize_transactions(df):
    """
    Categorize transactions based on description keywords.
    """
    # Preserve existing mappings and add new patterns
    account_mappings = {
        # Existing mappings remain unchanged
        'Supplies Expense': ['Send Money', 'Miscellaneous'],
        'Telephone Expense': ['Airtime', 'Topup', 'Telkom', 'Vodacom', 'MTN', 'Cell C'],
        
        # Enhanced Fuel category
        'Fuel Expense': [
            'Fuel', 'Engen', 'Total', 'Sasol', 'Trac Diamond Plaza', 'Doornpoort', 
            'Astron Energy', 'Petrol', 'BP', 'Caltex'
        ],
        
        # Enhanced Stationery category
        'Stationery and Printing': ['Game', 'Cenecon', 'Stationery', 'Office', 'Printing'],
        
        # Enhanced Business Meetings
        'Business Meetings': [
            'Nandos', 'Mcd', 'KFC', 'Chicken Licken', 'Tres Jolie', 'MCP', 'Lunch',
            'Steers', 'Galitos'
        ],
        
        # Enhanced Household category
        'Household Expense': [
            'Grocery', 'Shoprite', 'Food', 'Ndoziz Buy', 'Beder Cash And Chic', 
            'Diamond Hill', 'Checkers', 'Woolworths', 'PNP', 'Spar', 'Grocc', 
            'Gro ', 'Makro', 'Edgars', 'Markham', 'Clicks', 'Dischem', 'Pharmacy',
            'BBW', 'Cotton Lounge', 'Crazy Store', 'Jet', 'MRP', 'Mrprice',
            'Euro Rivonia', 'Ok Minimark', 'Valueco'
        ],
        
        # Enhanced Vehicle categories
        'Vehicle Hire': [
            'Car Hire', 'Car Rental', 'Truck Hire', 'Quantum Hire', 'Rentals', 
            'Outward Swift R024', 'Ez Truck Hire'
        ],
        
        # Enhanced Educational categories
        'Educational Expenses': [
            'Sch Fees', 'School', 'Education', 'Computer Lessons', 'Extra Lessons',
            'Simphiwe', 'Pathfinder', 'Kids For Kids'
        ],
        
        # Enhanced Bank Charges
        'Bank Charges': [
            'Penalty Interest', 'Service Fee', 'Bank Charges', 'Non FNB Withdrawal Fees',
            'Monthly Fees', 'Service Fees', 'Bank Charge', 'Account Fee', 'Item Fee',
            'Manual Reversal Fee', 'Unsuccessful F Declined', 'Unpaid No Funds',
            'Fee Tcib', 'Swift Commission', 'Replacement Fee', 'Card Fee',
            'Commission', 'Schd Trxn', 'Unpaid No Funds 01','Card POS Unsuccessful F Declined',
        ],
        
        # Enhanced Toll Fees
        'Toll Fees': [
            'Plaza', 'Toll', 'Baobab Plaza', 'Capricorn Plaza', 'Kranskop Plaza',
            'Nyl Plaza', 'Carousel', 'Pumulani', 'Middleburg Tap'
        ],
        
        # Enhanced Salaries and Wages
        'Salaries and Wages': [
            'Driver', 'Salary', 'Tendai', 'G Gr Gu', 'Bonakele', 'Ncube', 'Ze'
        ],
        
        # Enhanced Outsourced Services
        'Outsourced Services': [
            'Transport', 'Masik', 'Luc Trs', 'Mas', 'Samantha Mas Logistics'
        ],

        # Add new patterns to Vehicle Maintenance
        'Vehicle Maintenance': [
            # Existing patterns
            'Parts', 'Engine Parts', 'Truck Spares',
            # New patterns
            'Vw Parts', 'Engine Parts Luc'
        ],

        # Add new patterns to Business Meetings
        'Business Meetings': [
            # Existing patterns
            'Nandos', 'Mcd', 'KFC', 'Chicken Licken', 'Tres Jolie', 'MCP', 'Lunch',
            # New patterns
            'Nizams', 'Newscafe', 'Tonys Ca', 'Snack Shop', 'Rocky Liquor', 'Avianto'
        ],

        # Add new category for Electronics
        'Business Equipment': [
            'Verimark', 'African Electro', 'Incredible', 'Hpy*', 
            'Electronic', 'POS Consultin', 'Ikh*E POS', 'Yoco','CSB Cosmo City',
            'Braamfontein Superm', 'Mall', 'British A', 'Cellini', 'Ladies Fash',
            'Cash Build', 'Butchery', 'Valley View', 'Eden Perfumes', 'Bramfontein Sup'
        ],

        # Add new patterns to Household
        'Household Expense': [
            # Existing patterns
            'Grocery', 'Shoprite', 'Food', 'Ndoziz Buy', 'Beder Cash And Chic',
            'Diamond Hill', 'Checkers', 'Woolworths', 'Pick n Pay', 'Spar', 
            'Makro', 'Edgars','PNP', 'Clicks', 'Dischem', 'Pharmacy',
            'BBW', 'Cotton Lounge', 'Crazy Store', 'Jet', 'MRP', 'Mrprice',
            'Euro Rivonia', 'Ok Minimark', 'Valueco', 'Checkers Hyper','OK'
            # New patterns
            'Csb Cosmo City', 'Braamfontein Superm', 'Mall', 'British A',
            'Cellini', 'Ladies Fash', 'Cash Build', 'Butchery', 'Valley View',
            'Eden Perfumes', 'Bramfontein Sup'
        ],

        # Add new patterns to Bank Charges
        'Bank Charges': [
            # Existing patterns
            'Penalty Interest', 'Service Fee', 'Bank Charges', 
            'Non FNB Withdrawal Fees', 'Monthly Fees', 'Service Fees',
            # New patterns
            'Fee', 'Fees', 'Commission', 'Dr.Int.Rate',
            '!ERROR: unparsable description text!','Card POS Unsuccessful F Declined',
            'Unpaid No Funds', 'Fee Tcib', 'Swift Commission', 'Replacement Fee',
            'Card Fee', 'Commission', 'Schd Trxn', 'Unpaid No Funds 01',
            'Unpaid No Funds 02', 'Unpaid No Funds 03'
        ],

        # Add new patterns to Entertainment
        'Entertainment': [
            'DSTV', 'Ticketpros', 'Movies', 'Cinema','Liquorshop'
        ],

        # Add new category for Miscellaneous
        'Miscellaneous': [
            'Transfer To Trf', 'Transfer To Msu', 'Transfer To Ndu',
            'Transfer To Ukn', 'Transfer To Chantelle', 'Transfer To Sleeping Bag',
            'Transfer To Amn', 'Transfer To Mnc', 'Transfer To Sk','Liquorshop Cosmo',
            '4624616',
            'Payment To Msu',
            'Payment To Ndu',
            'S2S*Salamudestasupe',
            'Steers Balfour',
            'POS Purchase S2S*Salamudestasupe 428104*2012 03 Sep'
        ],

        # Existing categories remain unchanged
        'Travelling Expense': ['Uber'],
        'Drawings': ['ATM', 'Cash Advanc', 'Withdrawal', 'Cashback', 'Family Support'],
        'Director Remunerations': ['Lucky', 'Lk', 'Lucky Ncube', 'Gu', 'Gr', 'G', 'G','FNB App Transfer To', 'FNB App Payment To G ',
            'FNB App Payment To Gr', 'Payment To Gr', 'Payment To G '],
        'Internet Expense': ['Wifi', 'Internet', 'Home Wifi'],
        'Investment Expense': ['Invest', 'Investment'],
        'Cosmetics Expense': ['Cosmetics', 'Umumodi'],
        'Donations': ['Father\'S Day', 'Penlope Mail', 'Funeral'],
        'Bond Payment': ['Settlement', 'Mavondo', 'Rental', 'Rent'],
        'Interest Paid': ['Int On Debit Balance'],
        'Insurance': ['FNB Insure', 'Internal Debit Order'],
        'Income from Services': ['Payment From', 'Received', 'Deposit', 'Credit'],
        'Inter Account Transfers': ['Penlope Investments', 'Penelope Investments'],
        'Supplier Payments': ['Makhosin', 'Masikize', 'Supplier'],
        'Electricity': ['Electricity Prepaid'],
        'Assets': ['Furniture'],
        'Liabilities': ['Loan', 'Debt', 'Credit Card'],
        'Equity': ['Drawings', 'Retained Earnings'],
        'Office Rent': ['FNB App Payment To Flat', 'FNB App Payment To Office', 'FNB App Payment To Office Rent'],
    }

    # Add Account column with default value
    df['Account'] = 'Uncategorized'
    
    # Case-insensitive categorization
    for account, keywords in account_mappings.items():
        for keyword in keywords:
            # Convert description to lowercase for case-insensitive matching
            mask = df['description'].astype(str).str.lower().str.contains(
                keyword.lower(), na=False
            )
            df.loc[mask, 'Account'] = account
    
    # Additional categorization rules from audit analysis
    # Handle FNB App payments and transfers
    fnb_app_mask = df['description'].astype(str).str.contains('FNB App', case=False, na=False)
    df.loc[fnb_app_mask & df['description'].str.contains('Gro|Grocc', case=False, na=False), 'Account'] = 'Household Expense'
    df.loc[fnb_app_mask & df['description'].str.contains('Petrol', case=False, na=False), 'Account'] = 'Fuel Expense'
    df.loc[fnb_app_mask & df['description'].str.contains('Car|Rental|Hire', case=False, na=False), 'Account'] = 'Vehicle Hire'
    
    # Additional categorization rules
    credit_mask = (df['Type'] == 'Credit') & (~df['description'].astype(str).str.contains(
        'Int|Interest|Service Fee', case=False, na=False))
    df.loc[credit_mask & (df['Account'] == 'Uncategorized'), 'Account'] = 'Income from Services'
    
    # Add Account Type
    account_types = {
        'Income from Services': 'Income',
        'Supplier Payments': 'Expense',
        'Bank Charges': 'Expense',
        'Insurance': 'Expense',
        'Interest Paid': 'Expense',
        'Bond Payment': 'Expense',
        'Donations': 'Expense',
        'Cosmetics Expense': 'Expense',
        'Investment Expense': 'Expense',
        'Internet Expense': 'Expense',
        'Director Remunerations': 'Expense',
        'Salaries and Wages': 'Expense',
        'Educational Expenses': 'Expense',
        'Drawings': 'Equity',
        'Travelling Expense': 'Expense',
        'Vehicle Maintenance': 'Expense',
        'Outsourced Services': 'Expense',
        'Household Expense': 'Expense',
        'Business Meetings': 'Expense',
        'Stationery and Printing': 'Expense',
        'Fuel Expense': 'Expense',
        'Telephone Expense': 'Expense',
        'Supplies Expense': 'Expense',
        'Uncategorized': 'Unknown'
    }
    
    df['Account Type'] = df['Account'].map(account_types)
    
    return df

def generate_trial_balance(df):
    """
    Generate a trial balance from the categorized transactions.
    """
    trial_balance = df.groupby('Account').agg({
        'Debit': 'sum',
        'Credit': 'sum'
    }).reset_index()
    
    trial_balance['Net'] = trial_balance['Debit'] - trial_balance['Credit']
    trial_balance['Account Type'] = trial_balance['Account'].map(
        df.groupby('Account')['Account Type'].first())
    
    # Sort by account type and name
    trial_balance = trial_balance.sort_values(['Account Type', 'Account'])
    
    # Add totals row
    totals = pd.DataFrame({
        'Account': ['TOTAL'],
        'Debit': [trial_balance['Debit'].sum()],
        'Credit': [trial_balance['Credit'].sum()],
        'Net': [trial_balance['Net'].sum()],
        'Account Type': ['']
    })
    
    trial_balance = pd.concat([trial_balance, totals], ignore_index=True)
    
    return trial_balance

def generate_management_accounts(df):
    """
    Generate management accounts from the processed data.
    """
    # Calculate totals by account type
    account_totals = df.groupby(['Account Type', 'Account']).agg({
        'Debit': 'sum',
        'Credit': 'sum'
    }).reset_index()
    
    account_totals['Net'] = account_totals['Debit'] - account_totals['Credit']
    
    # Income Statement
    income_accounts = account_totals[account_totals['Account Type'] == 'Income']
    expense_accounts = account_totals[account_totals['Account Type'] == 'Expense']
    
    total_income = abs(income_accounts['Credit'].sum() - income_accounts['Debit'].sum())
    total_expenses = expense_accounts['Debit'].sum() - expense_accounts['Credit'].sum()
    net_profit = total_income - total_expenses
    
    income_statement = pd.DataFrame({
        'Category': ['Revenue', 'Less: Expenses', 'Net Profit/(Loss)'],
        'Amount': [total_income, total_expenses, net_profit]
    })
    
    # Balance Sheet
    assets = account_totals[account_totals['Account Type'] == 'Asset']['Net'].sum()
    liabilities = account_totals[account_totals['Account Type'] == 'Liability']['Net'].sum()
    equity = account_totals[account_totals['Account Type'] == 'Equity']['Net'].sum()
    
    balance_sheet = pd.DataFrame({
        'Category': ['Assets', 'Liabilities', 'Equity', 'Retained Earnings'],
        'Amount': [assets, liabilities, equity, net_profit]
    })
    
    return income_statement, balance_sheet

def generate_cashbook_excel(df, output_path):
    """
    Generate an Excel cashbook with management accounts.
    """
    with pd.ExcelWriter(output_path, engine='openpyxl') as writer:
        # Create monthly summary
        monthly_summary = df.groupby([pd.Grouper(key='date', freq='ME'), 'Account']).agg({
            'Debit': 'sum',
            'Credit': 'sum'
        }).reset_index()
        
        # Calculate Net after aggregation
        monthly_summary['Net'] = monthly_summary['Debit'] - monthly_summary['Credit']
        
        # Write each sheet
        # Format the date column before writing to Excel
        df_formatted = df.copy()
        df_formatted['date'] = df_formatted['date'].dt.strftime('%Y-%m-%d')
        
        monthly_summary_formatted = monthly_summary.copy()
        monthly_summary_formatted['date'] = monthly_summary_formatted['date'].dt.strftime('%Y-%m-%d')
        
        # Write to Excel
        df_formatted.to_excel(writer, sheet_name='Detailed Transactions', index=False)
        monthly_summary_formatted.to_excel(writer, sheet_name='Monthly Summary', index=False)
        
        # Generate and write trial balance
        trial_balance = generate_trial_balance(df)
        trial_balance.to_excel(writer, sheet_name='Trial Balance', index=False)
        
        # Format worksheets
        for sheet_name in writer.sheets:
            worksheet = writer.sheets[sheet_name]
            
            # Adjust column widths
            for idx, col in enumerate(worksheet.columns, 1):
                worksheet.column_dimensions[get_column_letter(idx)].width = 15
                
            # Format date columns to show as dates
            if sheet_name in ['Detailed Transactions', 'Monthly Summary']:
                # Format the date column (assuming it's the first column)
                for cell in worksheet['A'][1:]:  # Skip header row
                    try:
                        cell.number_format = 'yyyy-mm-dd'
                    except:
                        pass

if __name__ == "__main__":
    # Set the fiscal year date range
    start_date = '2024-03-01'
    end_date = '2025-02-28'
    
    # Get the input and output paths
    input_dir = '/Users/sthwalonyoni/pdf-bank-statement-parser/output'
    output_path = os.path.join(os.path.dirname(input_dir), "Annual_Cashbook_FY2024-2025.xlsx")
    
    try:
        # Combine and process CSV files
        df = combine_csv_files(input_dir, start_date, end_date)
        df = clean_and_process_csv(df)
        
        # Generate the Excel cashbook
        generate_cashbook_excel(df, output_path)
        print(f"\nAnnual cashbook generated successfully: {output_path}")
        
    except Exception as e:
        import traceback
        print(f"\nError: {e}")
        print("\nDetailed error information:")
        traceback.print_exc()